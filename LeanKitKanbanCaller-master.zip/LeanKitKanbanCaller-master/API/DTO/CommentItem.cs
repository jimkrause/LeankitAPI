﻿namespace API
{
    public class CommentItem
    {
        public string Comment { get; set; }
    }
}