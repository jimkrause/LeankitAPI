﻿namespace API.Entities
{
    public class User
    {
    }
}