﻿namespace API.Entities
{
    public class Type
    {
        public string Id { get; set; }
    }
}